---
name: Erreur factuelle
about: Un chiffre, une date, un groupe ou une attribution qui ne colle pas
labels: erreur factuelle
---

**Fiche concernée**
`fiches/AAAA-MM-JJ.json`

**Ce qui est écrit**

**Ce qui est exact**

**Source qui l'établit**
Lien vers la page « analyse du scrutin » de l'Assemblée, le compte rendu officiel,
le programme du parti, ou à défaut un article de presse daté.
