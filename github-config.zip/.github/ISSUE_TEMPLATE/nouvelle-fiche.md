---
name: Proposer une mesure
about: Une mesure qui mériterait sa fiche
labels: nouvelle fiche
---

**La mesure**

**Gauche ou droite ?** Et le clivage est-il brouillé ?

**Qui la porte**

**Y a-t-il eu un vote ?** Si oui, numéro du scrutin à l'Assemblée.

**La notion à expliquer**
Le concept que le lecteur ne connaît probablement pas et qui rend le débat clair.

**Sources**
