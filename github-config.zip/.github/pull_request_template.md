**Ce que change cette pull request**

**Sources**
<!-- Une source par affirmation nouvelle ou corrigée. Sans exception. -->

**Avant d'ouvrir**
- [ ] `python3 scripts/valider.py` passe
- [ ] `python3 scripts/build.py` relancé, `data.js` ajouté au commit
- [ ] La fiche a été jouée une fois dans un navigateur
- [ ] `arguments_pour` et `arguments_contre` sont aussi soignés l'un que l'autre
